// eslint-disable-next-line
globalThis = Function('return this')()
